from django.contrib import admin
from .models import Personne,Doc

# Register your models here.
admin.site.register(Personne)
admin.site.register(Doc)